 module.exports = {
 	article: require('./controllers/article')
 }